firebase.initializeApp({
  apiKey: "AIzaSyBeXuAn08dMjR_2xmqEe0M31cRIYqaKdQU",
  authDomain: "actprova-d4af7.firebaseapp.com",
  projectId: "actprova-d4af7",
  storageBucket: "actprova-d4af7.appspot.com",
  messagingSenderId: "132669681924",
  appId: "1:132669681924:web:ec88360241aa50a6bda051"
});

const auth = firebase.auth();