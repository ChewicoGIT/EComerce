firebase.initializeApp({
    apiKey: "AIzaSyC_HO2OruIhi2Cts2AG__4Zd2Fdw_3okhU",
    authDomain: "unbreakable-ties.firebaseapp.com",
    projectId: "unbreakable-ties",
    storageBucket: "unbreakable-ties.appspot.com",
    messagingSenderId: "444343399503",
    appId: "1:444343399503:web:53cc195f2c7359dbc6663a"
});

const auth = firebase.auth();